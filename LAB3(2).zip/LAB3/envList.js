const envList = [{"envId":"cloud1-3gqepjlv2f021467","alias":"cloud1"}]
const isMac = true
module.exports = {
    envList,
    isMac
}